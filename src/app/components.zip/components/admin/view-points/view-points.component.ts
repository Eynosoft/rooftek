import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-points',
  templateUrl: './view-points.component.html',
  styleUrls: ['./view-points.component.scss']
})
export class ViewPointsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
