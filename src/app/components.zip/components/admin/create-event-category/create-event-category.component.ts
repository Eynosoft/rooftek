import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-event-category',
  templateUrl: './create-event-category.component.html',
  styleUrls: ['./create-event-category.component.scss']
})
export class CreateEventCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
