import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-points',
  templateUrl: './add-points.component.html',
  styleUrls: ['./add-points.component.scss']
})
export class AddPointsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
