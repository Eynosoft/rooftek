import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-product-category',
  templateUrl: './create-product-category.component.html',
  styleUrls: ['./create-product-category.component.scss']
})
export class CreateProductCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
