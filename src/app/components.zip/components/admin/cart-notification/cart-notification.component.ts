import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-notification',
  templateUrl: './cart-notification.component.html',
  styleUrls: ['./cart-notification.component.scss']
})
export class CartNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
