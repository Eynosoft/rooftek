import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-detail',
  templateUrl: './agent-detail.component.html',
  styleUrls: ['./agent-detail.component.scss']
})
export class AgentDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
