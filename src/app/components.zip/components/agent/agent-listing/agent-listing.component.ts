import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-listing',
  templateUrl: './agent-listing.component.html',
  styleUrls: ['./agent-listing.component.scss']
})
export class AgentListingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
